#!/usr/bin/env python3
"""Write firmware.json for an MCUboot-signed application image.

The manifest contains the version, URL, size, SHA-256 digest, and optional
Ed25519 signature over that digest. The input must contain an MCUboot header.
See docs/firmware_update.md.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import sys
from pathlib import Path

from build_bundle import sign_digest

# MCUboot image magic, little-endian at offset 0.
MCUBOOT_MAGIC = 0x96F3B83D


def has_mcuboot_header(raw: bytes) -> bool:
    if len(raw) < 4:
        return False
    return int.from_bytes(raw[:4], "little") == MCUBOOT_MAGIC


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("image", type=Path, help="path to zephyr.signed.bin")
    parser.add_argument(
        "--version", required=True, help="release version, e.g. 0.2.0 — must match the VERSION file"
    )
    parser.add_argument(
        "--out", type=Path, default=None, help="output directory (default: <root>/dist/firmware)"
    )
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent.parent)
    parser.add_argument(
        "--sign-key",
        type=Path,
        default=None,
        help="ed25519 private key PEM; omit for an unsigned dev manifest",
    )
    parser.add_argument("--base-url", default="http://cicala.invalid/device")
    args = parser.parse_args(argv)

    raw = args.image.read_bytes()

    if not has_mcuboot_header(raw):
        print(
            f"{args.image} has no MCUboot header — this is the unsigned image, and a "
            "device would download it, verify it, and then fail to boot it. Use "
            "zephyr.signed.bin.",
            file=sys.stderr,
        )
        return 1

    out_dir = args.out or args.root / "dist" / "firmware"
    out_dir.mkdir(parents=True, exist_ok=True)

    name = f"cicala-{args.version}.bin"
    shutil.copyfile(args.image, out_dir / name)

    # Sign the exact bytes named by the manifest.
    digest = hashlib.sha256(raw).digest()
    sig = sign_digest(digest, args.sign_key) if args.sign_key else None

    if sig is None:
        print(
            f"warning: {name} is unsigned (no --sign-key); no device will install it",
            file=sys.stderr,
        )

    manifest = {
        "schema": 1,
        "version": args.version,
        "url": f"{args.base_url}/{name}",
        "size": len(raw),
        "sha256": digest.hex(),
        "sig": sig,
    }

    (out_dir / "firmware.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")

    print(f"{name}: {len(raw)} bytes, version {args.version}")
    print(f"firmware.json: {out_dir / 'firmware.json'}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
