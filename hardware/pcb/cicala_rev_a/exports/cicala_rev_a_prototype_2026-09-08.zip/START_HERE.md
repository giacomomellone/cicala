# Cicala Rev A engineering prototype handoff

Public working-source snapshot dated 2026-09-08. Read these first:

- hardware/pcb/MANUFACTURING.md: exact JLCPCB inputs and order settings.
- hardware/case/README.md: printing, button-stop adjustment and assembly.
- docs/firmware_rev_a.md: toolchain, build, flash, debug and recovery.
- hardware/pcb/REVIEW.md: findings, evidence and prototype acceptance.

Upload the inner hardware/pcb/cicala_rev_a/exports/cicala_rev_a_gerbers.zip
to the PCB fabrication field, then the two assembly/*_jlc_*.csv files
to the assembly fields. Do not upload this entire snapshot as Gerbers.

This snapshot contains public source files without Git metadata or
downloaded dependencies. Firmware commands assume a complete Git checkout
of https://github.com/giacomomellone/cicala containing these revised files.
No physical board, flash or print test is represented by the digital checks.
Factory CAM/sourcing and the documented first-prototype measurements remain.
